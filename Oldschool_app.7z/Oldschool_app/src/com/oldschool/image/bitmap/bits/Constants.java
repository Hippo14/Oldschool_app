package com.oldschool.image.bitmap.bits;

/**
 * Created by KMacioszek on 2016-08-29.
 */
public class Constants {

    public static final int BITS_1 = 1;
    public static final int BITS_8 = 8;
    public static final int BITS_24 = 24;
    public static final int BITS_24_GRAYSCALE = 240;

    public static final String BITMAP_TYPE = "BM";
}
