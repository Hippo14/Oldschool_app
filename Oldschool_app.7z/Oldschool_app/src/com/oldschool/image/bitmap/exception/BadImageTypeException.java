package com.oldschool.image.bitmap.exception;

/**
 * Created by KMacioszek on 2016-09-06.
 */
public class BadImageTypeException extends Exception {
    public BadImageTypeException(String message) {
        super(message);
    }
}
