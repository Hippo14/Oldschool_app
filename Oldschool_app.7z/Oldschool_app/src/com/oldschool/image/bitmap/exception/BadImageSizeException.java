package com.oldschool.image.bitmap.exception;

/**
 * Created by KMacioszek on 2016-09-06.
 */
public class BadImageSizeException extends Exception {
    public BadImageSizeException(String message) {
        super(message);
    }
}
