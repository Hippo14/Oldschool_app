package com.oldschool.image.bitmap.exception;

/**
 * Created by KMacioszek on 2016-09-05.
 */
public class UnknownFormatException extends Exception {
    public UnknownFormatException(String message) {
        super(message);
    }
}
